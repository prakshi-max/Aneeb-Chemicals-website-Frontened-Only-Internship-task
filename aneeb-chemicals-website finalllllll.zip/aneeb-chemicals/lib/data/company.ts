export const company = {
  name: "Aneeb Chemicals Pvt. Ltd.",
  shortName: "Aneeb Chemicals",
  tagline: "Engineering Trust into Every Bond",
  founded: 2014,
  gst: "09AAMCA8213G1ZL",
  phone: "+91 80454 78219",
  phoneRaw: "08045478219",
  email: "info@aneebchemicals.in",
  contactPerson: {
    name: "Himanshu Garg",
    role: "Marketing Manager",
  },
  factoryAddress:
    "Khasra No. 1250, Village Morta, Near Morta Road, Industrial Area, Ghaziabad – 201001, Uttar Pradesh, India",
  registeredAddress: "61/5, Jagriti Vihar, Meerut, Uttar Pradesh, India",
  facilityArea: "10,000 sq. meters",
  employees: 50,
  engineers: 5,
  annualTurnover: "INR 4 Crores",
  bankers: ["Punjab National Bank", "Yes Bank"],
  socials: {
    linkedin: "#",
    facebook: "#",
    youtube: "#",
  },
};

export const siteUrl = "https://www.aneebchemicals.in";
